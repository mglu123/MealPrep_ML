# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mealprep']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'mealprep',
    'version': '0.1.0',
    'description': 'Python package that ease the pain in fpre-processing like outlier finding, numerical/categorical data and etc.',
    'long_description': None,
    'author': 'luhuayue',
    'author_email': 'luhuayueapp@163.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
